public class Calculadora {
    private double operandOne;
    private double operandTwo;
    private char operation;
    private double result;

    public Calculadora() {
        this.operandOne = 0;
        this.operandTwo = 0;
        this.operation = '+';
    }

    public void performOperation(){
        switch (operation) {
            case '+':
                this.result = operandOne + operandTwo;
                break;
            case '-':
                this.result = operandOne - operandTwo;
                break;
            default:
                break;
        }
    }

    public double getOperandOne() {
        return operandOne;
    }

    public void setOperandOne(double operandOne) {
        this.operandOne = operandOne;
    }

    public double getOperandTwo() {
        return operandTwo;
    }

    public void setOperandTwo(double operandTwo) {
        this.operandTwo = operandTwo;
    }

    public char getOperation() {
        return operation;
    }

    public void setOperation(char operation) {
        this.operation = operation;
    }

    public double getResult(){
        return this.result;
    }
}
