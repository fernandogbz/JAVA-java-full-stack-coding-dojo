public class App {
    public static void main(String[] args) throws Exception {
        Calculadora calculator = new Calculadora();
        calculator.setOperandOne(10.5);
        calculator.setOperation('+');
        calculator.setOperandTwo(5.2); 
        calculator.performOperation();
        System.out.println(calculator.getResult());
    }
}
