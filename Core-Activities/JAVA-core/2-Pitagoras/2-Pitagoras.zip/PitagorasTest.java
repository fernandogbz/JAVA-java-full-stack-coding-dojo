public class PitagorasTest {
    public static void main(String[] args) {
        Pitagoras pitagoras = new Pitagoras();
        System.out.println(pitagoras.calcularHipotenusa(3, 4));
    }
}
