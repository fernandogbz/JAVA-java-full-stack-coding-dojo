import java.lang.Math;
public class Pitagoras {
    public double calcularHipotenusa(int catetoA, int catetoB) {
        return Math.sqrt(catetoA * catetoA + catetoB * catetoB);
    }
}

